package ru.alishev.springcourse;

public class KantryMusic implements Music {
    @Override
    public String getSong() {
        return "My my dor";
    }
}
