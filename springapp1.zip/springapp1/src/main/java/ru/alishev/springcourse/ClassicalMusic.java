package ru.alishev.springcourse;

public class ClassicalMusic implements Music {
    @Override
    public String getSong() {
        return "Hungarian rapsody";
    }
}
