package ru.alishev.springcourse;

public interface Music {
    String getSong();
}
